
#include "..\\./headers/tm4c123gh6pm.h"
#include "..\\./headers/LED.h"
#include "..\\./headers/Timer.h"
#include "..\\./headers/GPIO.h"

int i;

void Set_Led_Pin(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED1_PIN); // PB2
	Timer2(5);
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
	Timer2(5);
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
}
void Set_Led_2(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
}
void Clear_Led_2(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
}

void Set_Led_3(void)
{
	GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
}

void Clear_Led_3(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
}

void Clear_Led_Pin(void)
{
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED1_PIN); // PB2
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
	GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
}

void Blink_LEDS(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED1_PIN); // PB2
		Timer2(20);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED1_PIN); // PB2
		Timer2(20);
	}
}

void Blink_LEDS_2(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED2_PIN); // PB3
		Timer2(20);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED2_PIN); // PB3
		Timer2(20);
	}
}
void Blink_LEDS_3(void)
{
	for (i = 0; i < 3; i++)
	{
		GPIO_PORTB_DATA_R |= (1 << PORTB_LED3_PIN); // PB4
		Timer2(20);
		GPIO_PORTB_DATA_R &= ~(1 << PORTB_LED3_PIN); // PB4
		Timer2(20);
	}
}
